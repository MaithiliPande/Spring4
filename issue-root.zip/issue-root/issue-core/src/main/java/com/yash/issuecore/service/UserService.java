package com.yash.issuecore.service;

import java.util.List;

import com.yash.issuecore.domain.User;

public interface UserService {

	public User authenticateUser(String loginName, String password);
	
	public int registerNewUser(User user);

	public int updateUserDetails(User user);

	public List<User> listAllUsers();

	public User getUserByLoginName(String loginName);
}
