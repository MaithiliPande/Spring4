package com.yash.issuecore.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.yash.issuecore.dao.UserDAO;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.rowmapper.UserRowMapper;
import com.yash.issuecore.service.UserService;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public User authenticateUser(String loginName, String password) {
		User user = null;
		String sql = "SELECT * FROM users WHERE loginName=?";
		try {
			user = jdbcTemplate.queryForObject(sql, new UserRowMapper(), loginName);
			String encodedpass=getUserPassword(loginName);
			if(passwordEncoder.matches(encodedpass,password)){
			loadUserByUsername(user.getLoginName());
			return user;
			}
			else{
			throw new EmptyResultDataAccessException(1);	
			}
		} catch (EmptyResultDataAccessException ex) {
			return user;
		}
	}

	public int registerNewUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		return userDAO.insert(user);
	}

	public int updateUserDetails(User user) {
		return userDAO.update(user);
	}

	public List<User> listAllUsers() {
		return userDAO.list();
	}

	public User getUserByLoginName(String loginName) {
		return userDAO.getByLoginName(loginName);
	}

	public UserDetails loadUserByUsername(String loginName) throws UsernameNotFoundException {
		User user = userDAO.getByLoginName(loginName);
		if (user == null) {
			throw new UsernameNotFoundException("loginName Not Found in Database !");
		}
		List<String> roles = userDAO.getUserRoles(loginName);

		List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
		if (roles != null) {
			for (String role : roles) {
				System.out.println(role);
				GrantedAuthority authority = new SimpleGrantedAuthority(role);
				grantList.add(authority);
			}
		}
		String password=getUserPassword(user.getLoginName());
		return new org.springframework.security.core.userdetails.User(user.getLoginName(),
				password, grantList);	
		}
	
	private String getUserPassword(String loginName){
		return jdbcTemplate.queryForObject("SELECT password FROM users WHERE loginName=?", String.class, loginName);
	}
}
