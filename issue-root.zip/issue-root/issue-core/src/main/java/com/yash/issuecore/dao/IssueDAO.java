package com.yash.issuecore.dao;

import java.util.List;

import com.yash.issuecore.domain.Issue;

public interface IssueDAO {
	
	public List<Issue> list();
	
	public int insert(Issue issue);
	
	public List<Issue> listById(int userid);
	
	public int update(Issue issue);
	
	public int updateStatus(int id,int status);

}
