package com.yash.issuecore.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.issuecore.domain.Issue;

public class IssueRowMapper implements RowMapper<Issue> {

	public Issue mapRow(ResultSet rs, int rowNum) throws SQLException {
		Issue issue = new Issue();
		issue.setId(rs.getInt("id"));
		issue.setIssueName(rs.getString("issue"));
		issue.setCreatedDate(rs.getDate("createdDate"));
		issue.setIssueDescription(rs.getString("issueDescription"));
		issue.setIssueStatus(rs.getInt("issueStatus"));
		issue.setIssueType(rs.getInt("issueType"));
		issue.setUserid(rs.getInt("userid"));
		return issue;
	}

}
