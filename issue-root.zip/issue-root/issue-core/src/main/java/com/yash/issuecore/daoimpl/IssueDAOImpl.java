package com.yash.issuecore.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.issuecore.dao.IssueDAO;
import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.rowmapper.IssueRowMapper;
@Repository
public class IssueDAOImpl implements IssueDAO {
	
	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	
	public List<Issue> list() {
		String sql="SELECT * FROM issues";
		return jdbcTemplate.query(sql, new IssueRowMapper());
	}

	public int insert(Issue issue) {
		String sql="INSERT INTO issues(issue,issueType,userid,issueDescription,createdDate,issueStatus) VALUES(?,?,?,?,?,?)";
		Object[] params = {
				issue.getIssueName(),
				issue.getIssueType(),
				issue.getUserid(),
				issue.getIssueDescription(),
				issue.getCreatedDate(),
				issue.getIssueStatus()
		};
		return jdbcTemplate.update(sql, params);
	}

	public List<Issue> listById(int userid) {
		String sql = "SELECT * FROM issues WHERE userid=?";
		return jdbcTemplate.query(sql, new IssueRowMapper(),userid);
	}

	public int update(Issue issue) {
		String sql="UPDATE issues SET issue=?,issueType=?,userid=?,issueDescription=?,createdDate=?,issueStatus=? WHERE id=?";
		Object[] params = {
				issue.getIssueName(),
				issue.getIssueType(),
				issue.getUserid(),
				issue.getIssueDescription(),
				issue.getCreatedDate(),
				issue.getIssueStatus(),
				issue.getId()
		};
		return jdbcTemplate.update(sql,params);
	}

	public int updateStatus(int id, int status) {
		String sql="UPDATE issues SET issueStatus=? WHERE id=?";
		return jdbcTemplate.update(sql,status,id);
	}

}
