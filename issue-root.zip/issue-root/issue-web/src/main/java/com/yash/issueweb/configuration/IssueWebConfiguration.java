package com.yash.issueweb.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.yash.issuecore.configuration.SecurityConfiguration;

@Configuration
@EnableWebMvc
@ComponentScan("com.yash")
@Import(SecurityConfiguration.class)
public class IssueWebConfiguration{

	
}
