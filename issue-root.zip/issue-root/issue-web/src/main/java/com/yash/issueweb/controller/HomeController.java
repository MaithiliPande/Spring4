package com.yash.issueweb.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.request.WebRequest;

import com.yash.issuecore.domain.User;
import com.yash.issuecore.service.UserService;

@RestController
@SessionAttributes("userInSession")
public class HomeController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public User authenticateUser(HttpServletRequest request, @RequestBody User user) {
		User userObtain = userService.authenticateUser(user.getLoginName(), user.getPassword());
		System.out.println("called");
		if (userObtain != null) {
			request.getSession().setAttribute("userInSession", userObtain);
			if (userObtain.getRoleid() == 1) {
				System.out.println("Logged In Admin");
				return userObtain;
			}
			System.out.println("LoggedIn user");
			return userObtain;
		} else
			throw new UsernameNotFoundException("Username Not Found in DataBase");
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registerNewUser(@RequestBody User user) {
		int status = userService.registerNewUser(user);
		if (status > 0)
			return "User Registered";
		else
			return "User Not Registered";
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutUser(WebRequest request, SessionStatus status) {
		status.setComplete();
		request.removeAttribute("user", WebRequest.SCOPE_SESSION);
		return "Logged-Out";
	}
}
