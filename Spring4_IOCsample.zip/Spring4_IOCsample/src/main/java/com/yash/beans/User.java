package com.yash.beans;

public class User {
	private int id;
	private String name;
	private Address homeAddress;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	public void showUserDetail() {
		System.out.println("User ID: "+getId());
		System.out.println("Name :"+getName());
		System.out.println("Home Address");
		System.out.println("House No: "+getHomeAddress().getHouseNo());
		System.out.println("City: "+getHomeAddress().getCity());
		System.out.println("State: "+getHomeAddress().getState());
		System.out.println("Zip: "+getHomeAddress().getZip());
	}
}
