package com.yash.main;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.yash.beans.Address;
import com.yash.beans.User;

@Configuration		//<beans xsd></beans>
@ComponentScan(basePackages="com.yash.beans")//<context: component-scan/><
public class BeanConfig {
	@Bean//<bean id="" class=""/>
	public User user() {
		User user = new User();
		user.setId(101);
		user.setName("Maithili");
		user.setHomeAddress(homeAddress());
		return user;
	}
	@Bean
	public Address homeAddress() {
		Address homeAddress = new Address();
		homeAddress.setHouseNo("83");
		homeAddress.setCity("Nagpur");
		homeAddress.setState("Maharashtra");
		homeAddress.setZip("440025");
		return homeAddress;
		
	}
}
