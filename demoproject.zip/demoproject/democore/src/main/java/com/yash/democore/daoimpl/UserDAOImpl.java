package com.yash.democore.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.yash.democore.dao.UserDAO;
import com.yash.democore.model.User;
import com.yash.democore.rowmapper.UserRowMapper;

@Repository
public class UserDAOImpl implements UserDAO {


	@Autowired
	SessionFactory sessionFactory;
	
	
	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public User login(String loginname, String password) {
		String sql="select * from users where username=? and password=?";
		Object[] params =new Object[]{loginname,password};
		
		jdbcTemplate.query(sql,params, new UserRowMapper());
		return null;
	}

	public void register(User user) {
		
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();
		session.close();
		
	}

	public void delete(int id) {
		
		
	}

	public void update(User newUser) {
		
		
	}

	public List<User> listUsers(int id) {
		String sql="select * from users where id="+id;
		return jdbcTemplate.query(sql, new UserRowMapper());
	}

}
