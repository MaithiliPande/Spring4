package com.yash.spring.core;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
@Configuration
@Profile("prod")
public class ProdEnvConfig {
	@Bean
	public Employee employee() {
		return new Employee(101, "Maithili_Prod");
	}
}
