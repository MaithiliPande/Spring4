package com.yash.spring.core;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestClass {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.getEnvironment().setActiveProfiles("prod");
		context.scan("com.yash.spring.core");
		context.refresh();
		Employee employee = context.getBean(Employee.class);
		System.out.println("Employee id :" +employee.getId());
		System.out.println("Employee name :" +employee.getName());
		context.close();
	}
}
