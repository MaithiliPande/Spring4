package com.yash.issueweb.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.service.IssueService;

@RestController
public class IssueController {

	 @Autowired
	   private IssueService issueService;

	 
	  @RequestMapping(value="/issue",method=RequestMethod.POST)
	   public void save(@RequestBody Issue issue,HttpServletRequest httpServletRequest) {
		 HttpSession httpSession= httpServletRequest.getSession();
		 Integer userId=(Integer) httpSession.getAttribute("id");
		 issue.setUser_id(userId);
		 if(userId>0){
		 int id=issueService.insert(issue);
	   }else{
		   System.out.println("Credential Invalid");
	   }}
	  
	  @RequestMapping(value="/issue",method=RequestMethod.PUT)
	  public void edit(@RequestBody Issue issue) {
		  issueService.updateIssue(issue);
	  }
	  
	  @RequestMapping(value="/issue/{id}",method=RequestMethod.DELETE)
	  public void delete(@PathVariable("id") Integer id) {
		  issueService.delete(id);
	  }
	  @RequestMapping(value="/getAll", method=RequestMethod.GET)
	  public List<Issue> getAll(){
		  List<Issue> issueList=issueService.getAll();
		  return issueList;
	  }
	  
	
}
