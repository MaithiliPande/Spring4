package com.yash.issueweb.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.yash.issuecore.domain.User;
import com.yash.issuecore.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	 @Autowired
	   private UserService userService;

	 	
	  @RequestMapping(value="/add",method=RequestMethod.POST)
	   public void save(@RequestBody User user) {
		  int id=userService.insert(user);
		  System.out.println(id);
	     
	   }
	  
	  @RequestMapping(value="/edit",method=RequestMethod.PUT)
	  public void edit(@RequestBody User user) {
		  userService.update(user);
	  }
	  
	  @RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
	  public void delete(@PathVariable("id") Integer id) {
		  userService.delete(id);
	  }
	  @RequestMapping(value="/getAll", method=RequestMethod.GET)
	  public List<User> getAll(){
		  List<User> userList=userService.getAll();
		  return userList;
	  }
	  
	  @RequestMapping(value="/login", method=RequestMethod.POST)
	  public User authenticateUser(@RequestBody User user, HttpServletRequest httpServletRequest) {
		  User u=userService.authenticateUser(user.getLogin_name(),user.getPassword());
		 
		  
		  if(user!=null) {
			HttpSession httpSession= httpServletRequest.getSession(true);
			httpSession.setAttribute("User", u);
			httpSession.setAttribute("Id", u.getId());
			System.out.println(httpSession.getAttribute("Id"));
		  }
		  
		  return user;
	  }
	  
	  @RequestMapping(value="/logout", method=RequestMethod.POST)
	  public void LogoutUser(HttpServletRequest httpServletRequest) {
		HttpSession httpSession= httpServletRequest.getSession();
		httpSession.invalidate();
		
			  
	  }

	  
	
}
