package com.yash.issuecore.service;

import java.util.List;

import com.yash.issuecore.domain.User;

public interface UserService {
	public int insert(User user);
	
	public int update(User user);

	public int delete(Integer id);

	public List<User> getAll();

	public User authenticateUser(String login_name, String password);
}
