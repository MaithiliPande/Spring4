package com.yash.issuecore.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.issuecore.domain.User;

public class UserRowMapper implements RowMapper<User> {

	public User mapRow(ResultSet resultSet, int arg1) throws SQLException {
		User user=new User();
		user.setFirstName(resultSet.getString("first_name"));
		user.setLastName(resultSet.getString("last_name"));
		user.setEmail(resultSet.getString("email"));
		user.setLogin_name(resultSet.getString("login_name"));
		user.setPassword(resultSet.getString("password"));
		return user;
	}

}
