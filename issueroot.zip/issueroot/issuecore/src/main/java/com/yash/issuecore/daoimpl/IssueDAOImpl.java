package com.yash.issuecore.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.issuecore.dao.IssueDAO;
import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.rowmapper.IssueRowMapper;
@Repository
public class IssueDAOImpl implements IssueDAO{

	private JdbcTemplate jdbcTemplate;
	@Autowired
	public void setDataSource(DataSource dataSource) {
		
		this.jdbcTemplate=new JdbcTemplate(dataSource);
		
	}

	public int insert(Issue issue) {
		
	
		int result = 0;
		try {
			String sql="insert into issues(issue,issue_type,issue_description,user_id,status_id,created_date) values(?,?,?,?,?,?)";
			Object[] params={
				issue.getIssue(),
				issue.getIssue_type(),
				issue.getIssue_description(),
				issue.getUser_id(),
				issue.getStatus_id(),
				issue.getCreated_date()
			};
			result=jdbcTemplate.update(sql,params);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public int update(Issue issue) {
		int result = 0;
		try {
			String sql="update issues SET issue=?,issue_type=?,issue_description=?,status_id=? where id=?";
			Object[] params={
				issue.getIssue(),
				issue.getIssue_type(),
				issue.getIssue_description(),
				issue.getStatus_id(),
				issue.getId()
			};
			result=jdbcTemplate.update(sql,params);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public List<Issue> getAll() {
		List<Issue> issueList=new ArrayList();
		issueList=jdbcTemplate.query("select * from issues", new IssueRowMapper());
		return issueList;
	}

	public int delete(int issueId) {
		int result = 0;
		try {
			String sql="delete from issues where id=?";
			result=jdbcTemplate.update(sql,new Object[]{issueId});
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
