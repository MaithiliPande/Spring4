package com.yash.issuecore.serviceimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.yash.issuecore.dao.UserDAO;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.rowmapper.UserRowMapper;
import com.yash.issuecore.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;
	
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DataSource dataSource;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}
	public int insert(User user) {
		return userDAO.insert(user);
		
	}
	public int update(User user) {
		
		return userDAO.update(user);
	}
	public int delete(Integer id) {
		
		return userDAO.delete(id);
	}
	public List<User> getAll() {
		
		return userDAO.getAll();
	}
	public User authenticateUser(String login_name, String password) {
		User user=null;
		try {
			String sql="select * from users where login_name=? AND password=?;";
			Object[] params={
				login_name,
				password
			};
			user=jdbcTemplate.queryForObject(sql,params,new UserRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

}
