package com.yash.issuecore.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.issuecore.dao.UserDAO;
import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.rowmapper.IssueRowMapper;
import com.yash.issuecore.rowmapper.UserRowMapper;

@Repository
public class UserDAOImpl implements UserDAO {

	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DataSource dataSource;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}

	public int insert(User user) {
		
		int result = 0;
		try {
			String sql="insert into users(first_name,email,login_name,password,last_name) values(?,?,?,?,?)";
			Object[] params={
				user.getFirstName(),
				user.getEmail(),
				user.getLogin_name(),
				user.getPassword(),
				user.getLastName()
			};
			result=jdbcTemplate.update(sql,params);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public int update(User user) {
		int result=0;
		String sql="update users SET first_name=?,email=?,login_name=?,password=?,last_name=? where id=?";
		Object[] params={
				user.getFirstName(),
				user.getEmail(),
				user.getLogin_name(),
				user.getPassword(),
				user.getLastName(),
				user.getId()
			};
		result=jdbcTemplate.update(sql,params);
		return result;
	}

	public List<User> getAll() {
		List<User> userList=new ArrayList();
		userList=jdbcTemplate.query("select * from users", new UserRowMapper());
		return userList;
	}

	public int delete(int userId) {
		int result = 0;
		try {
			String sql="delete from users where id=?";
			result=jdbcTemplate.update(sql,new Object[]{userId});
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	 }
	}
	
	
	
	

