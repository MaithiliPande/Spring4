package com.yash.issuecore.service;

import java.util.List;

import com.yash.issuecore.domain.Issue;

public interface IssueService {

	public int insert(Issue issue);

	public int updateIssue(Issue issue);

	public int delete(Integer id);

	public List<Issue> getAll();
}
