package com.yash.issuecore.domain;

import java.sql.Date;

public class Issue {

	private int id;
	private String issue;
	private String issue_type;
	private int user_id;
	private String issue_description;
	private Date created_date;
	private int status_id;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the issue
	 */
	public String getIssue() {
		return issue;
	}
	/**
	 * @param issue the issue to set
	 */
	public void setIssue(String issue) {
		this.issue = issue;
	}
	/**
	 * @return the issue_type
	 */
	public String getIssue_type() {
		return issue_type;
	}
	/**
	 * @param issue_type the issue_type to set
	 */
	public void setIssue_type(String issue_type) {
		this.issue_type = issue_type;
	}
	/**
	 * @return the user_id
	 */
	public int getUser_id() {
		return user_id;
	}
	/**
	 * @param user_id the user_id to set
	 */
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	/**
	 * @return the issue_description
	 */
	public String getIssue_description() {
		return issue_description;
	}
	/**
	 * @param issue_description the issue_description to set
	 */
	public void setIssue_description(String issue_description) {
		this.issue_description = issue_description;
	}
	/**
	 * @return the created_date
	 */
	public Date getCreated_date() {
		return created_date;
	}
	/**
	 * @param created_date the created_date to set
	 */
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	/**
	 * @return the status_id
	 */
	public int getStatus_id() {
		return status_id;
	}
	/**
	 * @param status_id the status_id to set
	 */
	public void setStatus_id(int status_id) {
		this.status_id = status_id;
	}
	
	
	
}
