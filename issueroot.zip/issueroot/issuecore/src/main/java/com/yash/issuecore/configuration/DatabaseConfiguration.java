package com.yash.issuecore.configuration;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@Configuration
@PropertySource("classpath:jdbc.properties")
@ComponentScan(value="com.yash")
public class DatabaseConfiguration {

	@Autowired
	private Environment env;
	
	@Bean
	public BasicDataSource basicDataSource(){
		BasicDataSource basicDataSource=new BasicDataSource();
		basicDataSource.setDriverClassName(env.getProperty("jdbc.drivername"));
		basicDataSource.setUrl(env.getProperty("jdbc.url"));
		basicDataSource.setUsername(env.getProperty("jdbc.username"));
		basicDataSource.setPassword(env.getProperty("jdbc.password"));
		return  basicDataSource;
	}
	
}
