package com.yash.issuecore.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.yash.issuecore.domain.Issue;

public class IssueRowMapper implements RowMapper<Issue>{

	public Issue mapRow(ResultSet resultSet, int arg1) throws SQLException {
		Issue issue=new Issue();
		issue.setId(resultSet.getInt("id"));
		issue.setIssue(resultSet.getString("issue"));
		issue.setCreated_date(resultSet.getDate("created_date"));
		issue.setIssue_type(resultSet.getString("issue_type"));
		issue.setIssue_description(resultSet.getString("issue_description"));
		issue.setStatus_id(resultSet.getInt("status_id"));
		return issue;
	}

}
