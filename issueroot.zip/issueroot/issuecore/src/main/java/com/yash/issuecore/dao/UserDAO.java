package com.yash.issuecore.dao;

import java.util.List;

import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.domain.User;

public interface UserDAO {
	public int insert(User user);
	public int update(User user);
	public List<User> getAll();
	public int delete(int issueId);
}
