package com.yash.issuecore.util;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class DBUtil {
	private JdbcTemplate jdbcTemplate;

	
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}

	/**
	 * @return the jdbcTemplate
	 */
	public JdbcTemplate getJdbcTemplate() {
		
		return jdbcTemplate;
	}

	
	
	
}
