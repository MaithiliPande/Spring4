package com.yash.issuecore.dao;

import java.util.List;

import com.yash.issuecore.domain.Issue;

public interface IssueDAO {
	public int insert(Issue issue);
	public int update(Issue issue);
	public List<Issue> getAll();
	public int delete(int issueId);
}
