package com.yash.util;

import java.util.Hashtable;

import javax.naming.Context;

public class IntializeHashTableEnvironmentVariablesForContext {

	Hashtable<String, Object> environment;

	public Hashtable<String, Object> intializeHashTableVariables(String email, String password) {

		environment = new Hashtable<>();
		environment.put(Context.SECURITY_AUTHENTICATION, BasicInitializations.LDAP_SECURITY_AUTHENTICATION);
		environment.put(Context.INITIAL_CONTEXT_FACTORY, BasicInitializations.LDAP_INITIAL_CONTEXT_FACTORY);
		environment.put(Context.PROVIDER_URL, BasicInitializations.LDAP_PROVIDER_URL);
		environment.put(Context.SECURITY_PRINCIPAL, email);//username
		environment.put(Context.SECURITY_CREDENTIALS, password);//passowrd
		environment.put("java.naming.ldap.attributes.binary", "objectSID");
		return environment;

	}

}
