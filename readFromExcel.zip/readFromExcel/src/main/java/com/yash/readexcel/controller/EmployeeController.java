package com.yash.readexcel.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.yash.readexcel.domain.Employee;

@RestController
public class EmployeeController {

	@RequestMapping(value="/uploadFile",method=RequestMethod.POST)
	public ModelAndView readExcel(Model model, @RequestParam("excelfile") MultipartFile excelfile) {		
		try {
			System.out.println("in controller.......");
			List<Employee> listEmployee = new ArrayList<Employee>();
			int i = 0;
			// Creates a workbook object from the uploaded excelfile
			XSSFWorkbook workbook = new XSSFWorkbook(excelfile.getInputStream());
			// Creates a worksheet object representing the first sheet
			XSSFSheet worksheet = workbook.getSheetAt(0);
			// Reads the data in excel file until last row is encountered
			while (i <= worksheet.getLastRowNum()) {
				// Creates an object for the UserInfo Model
				Employee employee = new Employee();
				// Creates an object representing a single row in excel
				XSSFRow row = worksheet.getRow(i++);
				// Sets the Read data to the model class
				employee.setId((int) row.getCell(0).getNumericCellValue());
				employee.setName(row.getCell(1).getStringCellValue());
				employee.setSalary((int)row.getCell(2).getNumericCellValue());
				// persist data into database in here
				listEmployee.add(employee);
			}			
			workbook.close();
			model.addAttribute("listEmployee", listEmployee);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("index.jsp");
	}
}
