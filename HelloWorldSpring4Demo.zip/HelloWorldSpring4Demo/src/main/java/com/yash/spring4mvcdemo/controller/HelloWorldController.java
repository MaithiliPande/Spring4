package com.yash.spring4mvcdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

@Controller
public class HelloWorldController {
	public String sayHelloWorld(ModelMap model) {
		model.addAttribute("greeting", "Hi! Hello from Spring MVC");
		return "welcome";
	}
}
