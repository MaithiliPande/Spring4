package com.yash.demomaven.dao;

import com.yash.demomaven.domain.Employee;

/**
 * this interface will perform the operations related users.
 * It contains abstract methods of the operations.
 * @author maithili.pande
 *
 */
public interface EmployeeDAO {
	public int insert(Employee employee);
}
