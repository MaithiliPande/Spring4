package com.yash.demomaven.service;

import com.yash.demomaven.domain.Employee;

/**
 * This will perform service related tasks on employee
 */
public interface EmployeeService {
	public int register(Employee employee);
}
