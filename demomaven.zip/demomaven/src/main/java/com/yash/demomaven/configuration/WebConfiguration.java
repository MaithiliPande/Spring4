package com.yash.demomaven.configuration;



import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
@ComponentScan(value="com.yash.demomaven")
public class WebConfiguration extends DatabaseConfiguration {
	
	
}
