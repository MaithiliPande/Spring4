package com.yash.demomaven.daoimpl;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.demomaven.dao.EmployeeDAO;
import com.yash.demomaven.domain.Employee;

/**
 * This is the implementation class of EmployeeDAO interface.
 * It has the method implementations. 
 * @author maithili.pande
 *
 */
@Repository
public class EmployeeDAOImpl implements EmployeeDAO {
	private static Logger logger= Logger.getLogger(EmployeeDAOImpl.class);
	@Autowired
	SessionFactory sessionFactory;
	
	/**
	 * This method performs the operation to insert the employee into database.
	 */
	@Override
	public int insert(Employee employee) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		logger.info("Employee inserted successfully");
		return 1;
	}

}
