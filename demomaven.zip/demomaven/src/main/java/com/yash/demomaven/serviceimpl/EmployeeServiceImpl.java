package com.yash.demomaven.serviceimpl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.demomaven.dao.EmployeeDAO;
import com.yash.demomaven.domain.Employee;
import com.yash.demomaven.service.EmployeeService;

/**
 * This class is implementation of EmployeeService interface.
 */
@Service
public class EmployeeServiceImpl implements EmployeeService{
	private static Logger logger= Logger.getLogger(EmployeeServiceImpl.class);
	@Autowired
	private EmployeeDAO employeeDAO;

	@Override
	public int register(Employee employee) {
		logger.info("In register service");
		return employeeDAO.insert(employee);
	}

}
