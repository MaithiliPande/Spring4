package com.yash.demomaven.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.yash.demomaven.domain.Employee;
import com.yash.demomaven.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	/**
	 * This method will control the request and perform the registration operation accordingly.
	 * @param employee
	 * @return
	 */
	@RequestMapping(value="/addEmployee",method=RequestMethod.POST)
	public ModelAndView registerEmployee(@ModelAttribute Employee employee) {
		System.out.println(employee.getContact()+"in controller....");
		
//		return employeeService.register(employee);
		employeeService.register(employee);
		return new ModelAndView("index.jsp");
	}
	
	
}
